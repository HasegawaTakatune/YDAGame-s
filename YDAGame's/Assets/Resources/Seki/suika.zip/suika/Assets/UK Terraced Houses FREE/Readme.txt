Introduction:
A collection of 5 low poly terraced style houses, absolutely ideal for any background town / city scene.
Just drag any of the house prefabs into your project hierarchy to add a house to your scene.

Package Contents:
- 5 unique house models
- Each house is mirrored meaning 10 houses overall

Triangle Counts:
Between 350 & 850 Triangles per house

Extra Info:
If you have any issues then please dont hesitate to contact me >> rik4000@yahoo.com

Thanks and enjoy.